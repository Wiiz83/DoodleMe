function users(id, nom, prenom, pseudo, mdp){
	this.nom = nom;
	this.prenom = prenom;
	this.pseudo = pseudo;
	this.mdp = mdp;
}


var getNom = function(id){
	if (typeof listeUsers[id] != 'undefined'){
		return listeUsers[id].nom;
	}
}

var getPrenom = function(id){
	if (typeof listeUsers[id] != 'undefined'){
		return listeUsers[id].prenom;
	}
}

app.get('/users/', function(req, res){
	if(event.listeUsers != null){
		res.json(connection.query('SELECT * FROM users'));	
	}else{
		res.status(400).json({error: 'Aucun utilisateur !'});
	}
})

app.put('/user/', function (req, res) {
	res.setHeader('Content-Type', 'text/html');
    console.log(req.query);
    if(typeof req.params.id === 'undefined') {
    	res.status(400).json({ error: 'Utilisateur non trouvé' });
    }else if(event.listeUsers[id] != 'undefined'){
    	connection.query('UPDATE TABLE users SET nom='req.body.nom', prenom='req.body.prenom', pseudo='req.body.pseudo' WHERE idUser='req.body.id';');
    	res.json(connection.query('SELECT * FROM user WHERE idUser='req.body.idUser';'));
    	res.json(event.listeUsers[id]);
    }else{
    	res.status(400).json({error: 'Erreur lors de la modification'});
    }
})

app.post('/user/', function (req, res){
	if(typeof req.body.id === 'undefined' || typeof req.body.nom === 'undefined' || typeof req.body.prenom === 'undefined'){
		res.status(400).json({error: 'Utilisateur non enregistré'});
	}else if(user.listeUsers[req.body.id] != 'undefined'){
		res.status(400).json({error: 'Utilisateur déjà existant'});
	}else{
		res.json(connection.query('INSERT INTO users(nomU, prenomU, pseudo, mdp) VALUES ('req.body.nom', 'req.body.prenom', 'req.body.pseudo', 'req.body.mdp')'));
	}
})

app.get('/user/:id', function(req, res){
	if(typeof req.params.id === 'undefined') {
    	res.status(400).json({ error: 'utilisateur non trouvé' });
    }else if(event.listeEvents[id] != 'undefined'){
    	res.json(connection.query('SELECT * FROM users WHERE idUser = 'req.body.idUser';'));
    }else{
    	res.status(400).json({error: 'Erreur lors de la récupération de l\'utilisateur'});
    }
})